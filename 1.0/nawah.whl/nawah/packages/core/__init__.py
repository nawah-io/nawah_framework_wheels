# Ancora Imparo.

from nawah.classes import PACKAGE_CONFIG

config = PACKAGE_CONFIG(
	api_level='1.0',
	version='1.0.0'
)
